package com.appdynamics.pmdemoapps.android.ECommerceAndroid.misc;

public final class PreferenceConstants {
    public final static String END_POINT_URL = "http://54.190.107.43/appdynamicspilot/";
    public static final String EUM_APP_KEY = "DEMO-AAB-AUP";
    public static final String EUM_COLLECTOR_URL = "http://54.244.95.83:9001";
}
