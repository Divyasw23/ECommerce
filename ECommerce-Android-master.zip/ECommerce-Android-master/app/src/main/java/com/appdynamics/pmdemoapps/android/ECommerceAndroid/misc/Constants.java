package com.appdynamics.pmdemoapps.android.ECommerceAndroid.misc;

public final class Constants {
	
	public static final String COMMON_PREFS_FILE_NAME = "ShoppingDemoFile"; 
	
	public static final String COMMON_PREFS_USERNAME = "username";
	public static final String COMMON_PREFS_PASSWORD = "password";
	
}
